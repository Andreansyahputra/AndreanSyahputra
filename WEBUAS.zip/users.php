<?php
include 'config.php';
if (!isset($_SESSION['login']) || $_SESSION['role'] != 'admin') header("Location: login.php");

$data = $conn->query("SELECT * FROM users");
?>

<h2>Daftar User</h2>
<table border="1">
    <tr><th>ID</th><th>Username</th><th>Role</th></tr>
    <?php while ($row = $data->fetch_assoc()): ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= $row['username'] ?></td>
        <td><?= $row['role'] ?></td>
    </tr>
    <?php endwhile; ?>
</table>
