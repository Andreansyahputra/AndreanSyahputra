<?php
// config.php
session_start(); // Mulai session
$conn = new mysqli("localhost", "root", "", "footballshop");

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
