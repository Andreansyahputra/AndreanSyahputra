<?php
// tambah_kategori.php
include 'config.php';

// Cek apakah user sudah login
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Jika form dikirim
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = trim($_POST['nama']);

    // Validasi input
    if (!empty($nama)) {
        // Simpan ke database
        $sql = "INSERT INTO kategori (nama_kategori) VALUES ('$nama')";
        if ($conn->query($sql)) {
            $sukses = "Kategori berhasil ditambahkan.";
        } else {
            $error = "Gagal menambahkan kategori.";
        }
    } else {
        $error = "Nama kategori tidak boleh kosong.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Kategori</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #00695c, #26a69a);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', sans-serif;
        }
        .card {
            background-color: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.3);
            max-width: 400px;
            width: 100%;
        }
        h2 {
            color: #00695c;
        }
    </style>
</head>
<body>

<div class="card">
    <h2 class="text-center mb-4">➕ Tambah Kategori</h2>

    <?php if (isset($sukses)): ?>
        <div class="alert alert-success"><?= $sukses ?></div>
    <?php elseif (isset($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="post">
        <div class="mb-3">
            <label for="nama" class="form-label">Nama Kategori</label>
            <input type="text" name="nama" id="nama" class="form-control" placeholder="Contoh: Jersey" required>
        </div>
        <button type="submit" class="btn btn-success w-100">Tambah</button>
        <a href="kategori.php" class="btn btn-secondary w-100 mt-2">Kembali</a>
    </form>
</div>

</body>
</html>
