<?php
include 'config.php';
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Football Club</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
       body {
    background-image: url('img/stadion.jpg');
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center;
    background-attachment: fixed;
    min-height: 100vh;
    font-family: 'Segoe UI', sans-serif;
}

        .welcome-box {
            background-color: rgba(255, 255, 255, 0.95); /* putih transparan */
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
        }

        .btn-custom {
            transition: transform 0.2s ease;
            font-size: 1.1rem;
            padding: 10px 0;
        }

        .btn-custom:hover {
            transform: scale(1.05);
        }
    </style>
</head>
<body>

<div class="container py-5">
    <div class="welcome-box text-center mb-4">
        <h1 class="text-primary">Selamat datang, <?= htmlspecialchars($_SESSION['username']) ?>!</h1>
        <p class="text-secondary">Sistem penjualan tiket & merchandise resmi klub sepak bola.</p>
    </div>

    <div class="row g-4 text-center">
        <div class="col-md-3">
            <a href="tiket.php" class="btn btn-primary btn-custom w-100">🎟 Kelola Tiket</a>
        </div>
        <div class="col-md-3">
            <a href="merchandise.php" class="btn btn-success btn-custom w-100">🛍 Kelola Merchandise</a>
        </div>
        <div class="col-md-3">
            <a href="pesanan.php" class="btn btn-warning btn-custom w-100 text-white">📋 Riwayat Pesanan</a>
        </div>
        <div class="col-md-3">
            <a href="logout.php" class="btn btn-danger btn-custom w-100">🚪 Logout</a>
        </div>
    </div>
</div>

</body>
</html>
