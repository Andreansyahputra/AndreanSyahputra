<?php
session_start();
include 'config.php';

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

// Handle form tambah
if (isset($_POST['tambah'])) {
    $pertandingan = $_POST['pertandingan'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    // Upload gambar
    $gambar = $_FILES['gambar']['name'];
    $tmp = $_FILES['gambar']['tmp_name'];
    $folder = "uploads/";

    if (!file_exists($folder)) {
        mkdir($folder, 0777, true);
    }

    $path = $folder . time() . "_" . basename($gambar);
    move_uploaded_file($tmp, $path);

    $conn->query("INSERT INTO tiket (pertandingan, harga, stok, gambar) VALUES ('$pertandingan', '$harga', '$stok', '$path')");
}

// Search
$search = isset($_GET['search']) ? $_GET['search'] : '';
$data = $conn->query("SELECT * FROM tiket WHERE pertandingan LIKE '%$search%'");

// Hapus
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $get = $conn->query("SELECT gambar FROM tiket WHERE id=$id");
    $row = $get->fetch_assoc();

    if (!empty($row['gambar']) && file_exists($row['gambar'])) {
        unlink($row['gambar']);
    }

    $conn->query("DELETE FROM tiket WHERE id=$id");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Tiket</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            min-height: 100vh;
            color: white;
            font-family: 'Segoe UI', sans-serif;
        }

        .container {
            margin-top: 50px;
        }

        .card {
            background-color: rgba(255, 255, 255, 0.95);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
            color: black;
        }

        .form-control, .btn {
            font-size: 1.1rem;
        }

        table {
            font-size: 1.1rem;
        }

        th {
            background-color: #1e3c72;
            color: white;
        }

        img {
            max-width: 80px;
            border-radius: 8px;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="card">
        <h2 class="mb-4 text-center text-primary">🎟 Data Tiket Pertandingan</h2>

        <!-- Form Tambah Tiket -->
        <form method="post" class="row g-3 mb-4" enctype="multipart/form-data">
            <div class="col-md-3">
                <input type="text" name="pertandingan" class="form-control" placeholder="Nama Pertandingan" required>
            </div>
            <div class="col-md-2">
                <input type="number" name="harga" class="form-control" placeholder="Harga Tiket" required>
            </div>
            <div class="col-md-2">
                <input type="number" name="stok" class="form-control" placeholder="Stok Tiket" required>
            </div>
            <div class="col-md-3">
                <input type="file" name="gambar" class="form-control" accept="image/*" required>
            </div>
            <div class="col-md-2">
                <button name="tambah" class="btn btn-success w-100">Tambah</button>
            </div>
        </form>

        <!-- Form Search -->
        <form method="get" class="row g-3 mb-4">
            <div class="col-md-10">
                <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" class="form-control" placeholder="Cari tiket...">
            </div>
            <div class="col-md-2">
                <button class="btn btn-primary w-100">Cari</button>
            </div>
        </form>

        <!-- Tabel Tiket -->
        <table class="table table-bordered table-striped text-center">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Pertandingan</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Gambar</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $data->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['pertandingan'] ?></td>
                    <td>Rp <?= number_format($row['harga'], 0, ',', '.') ?></td>
                    <td><?= $row['stok'] ?></td>
                    <td>
                        <?php if (!empty($row['gambar']) && file_exists($row['gambar'])): ?>
                            <img src="<?= $row['gambar'] ?>" alt="Gambar">
                        <?php else: ?>
                            <span class="text-muted">Tidak ada</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="?hapus=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus data ini?')">Hapus</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>