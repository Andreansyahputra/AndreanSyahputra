<?php
include 'config.php';
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
}

// Tambah Merchandise
if (isset($_POST['tambah'])) {
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];
    $kategori = $_POST['kategori'];
    $conn->query("INSERT INTO merchandise (nama_barang, harga, stok, kategori_id) VALUES ('$nama', '$harga', '$stok', '$kategori')");
}

// Ambil data kategori
$kategori = $conn->query("SELECT * FROM kategori");

// Hapus data
if (isset($_GET['hapus'])) {
    $conn->query("DELETE FROM merchandise WHERE id=" . $_GET['hapus']);
}

// Tampilkan semua merchandise
$data = $conn->query("SELECT merchandise.*, kategori.nama_kategori FROM merchandise JOIN kategori ON merchandise.kategori_id = kategori.id");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Merchandise</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #4a148c, #880e4f, #f3e5f5);
            min-height: 100vh;
            font-family: 'Segoe UI', sans-serif;
            color: white;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            background-color: rgba(255, 255, 255, 0.96);
            color: #333;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.3);
        }
        h2 {
            font-size: 2rem;
            color: #6a1b9a;
        }
        .form-control, .btn {
            font-size: 1.1rem;
        }
        table {
            font-size: 1.1rem;
        }
        th {
            background-color: #6a1b9a;
            color: white;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="card">
        <h2 class="text-center mb-4">🛍️ Data Merchandise Klub</h2>

        <!-- Form tambah merchandise -->
        <form method="post" class="row g-3 mb-4">
            <div class="col-md-3">
                <input type="text" name="nama" class="form-control" placeholder="Nama Barang" required>
            </div>
            <div class="col-md-3">
                <input type="number" name="harga" class="form-control" placeholder="Harga" required>
            </div>
            <div class="col-md-2">
                <input type="number" name="stok" class="form-control" placeholder="Stok" required>
            </div>
            <div class="col-md-3">
                <select name="kategori" class="form-select" required>
                    <option value="" disabled selected>Pilih Kategori</option>
                    <?php while ($k = $kategori->fetch_assoc()): ?>
                        <option value="<?= $k['id'] ?>"><?= $k['nama_kategori'] ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-1">
                <button name="tambah" class="btn btn-success w-100">+</button>
            </div>
        </form>

        <!-- Tabel merchandise -->
        <table class="table table-bordered table-striped text-center">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Kategori</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $data->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['nama_barang'] ?></td>
                    <td>Rp <?= number_format($row['harga'], 0, ',', '.') ?></td>
                    <td><?= $row['stok'] ?></td>
                    <td><?= $row['nama_kategori'] ?></td>
                    <td>
                        <a href="edit_merchandise.php?id=<?= $row['id'] ?>" class="btn btn-info btn-sm">Edit</a>
                        <a href="?hapus=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus barang ini?')">Hapus</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
