<?php
include 'config.php';
if (!isset($_SESSION['login'])) header("Location: login.php");

// Simpan pesanan
if (isset($_POST['pesan'])) {
    $produk_id = $_POST['produk'];
    $jenis = $_POST['jenis'];
    $jumlah = $_POST['jumlah'];

    // Ambil detail produk berdasarkan jenis & ID
    if ($jenis == 'tiket') {
        $produk = $conn->query("SELECT * FROM tiket WHERE id=$produk_id")->fetch_assoc();
        $nama_produk = $produk['pertandingan'];
        $harga = $produk['harga'];
    } else {
        $produk = $conn->query("SELECT * FROM merchandise WHERE id=$produk_id")->fetch_assoc();
        $nama_produk = $produk['nama_barang'];
        $harga = $produk['harga'];
    }

    $total = $harga * $jumlah;
    $user_id = $conn->query("SELECT id FROM users WHERE username='{$_SESSION['username']}'")->fetch_assoc()['id'];

    $conn->query("INSERT INTO pesanan (user_id, produk, jenis, harga, jumlah, total) 
        VALUES ('$user_id', '$nama_produk', '$jenis', '$harga', '$jumlah', '$total')");
}

// Ambil data produk
$tiket = $conn->query("SELECT * FROM tiket");
$merch = $conn->query("SELECT merchandise.*, kategori.nama_kategori 
                      FROM merchandise 
                      JOIN kategori ON merchandise.kategori_id = kategori.id");

// Ambil pesanan user
$data = $conn->query("SELECT * FROM pesanan WHERE user_id = (
    SELECT id FROM users WHERE username='{$_SESSION['username']}')");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Pesan Produk</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(to right, #283e51, #485563);
            color: white;
            min-height: 100vh;
            font-family: 'Segoe UI', sans-serif;
        }
        .card {
            background-color: #fff;
            color: #333;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 6px 16px rgba(0,0,0,0.3);
        }
        h2 {
            color: #0d47a1;
        }
        th {
            background-color: #0d47a1;
            color: white;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="card">
        <h2 class="text-center mb-4">🛒 Form Pemesanan</h2>

        <!-- Form Pemesanan -->
        <form method="post" class="row g-3 mb-4">
            <div class="col-md-4">
                <label>Produk Tiket</label>
                <select name="produk" class="form-select" required onchange="document.getElementById('jenis').value='tiket'">
                    <option value="">-- Pilih Tiket --</option>
                    <?php while ($t = $tiket->fetch_assoc()): ?>
                        <option value="<?= $t['id'] ?>">🎟 <?= $t['pertandingan'] ?> - Rp<?= number_format($t['harga'], 0, ',', '.') ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label>Produk Merchandise</label>
                <select name="produk" class="form-select" required onchange="document.getElementById('jenis').value='merchandise'">
                    <option value="">-- Pilih Merchandise --</option>
                    <?php while ($m = $merch->fetch_assoc()): ?>
                        <option value="<?= $m['id'] ?>">🧢 <?= $m['nama_barang'] ?> (<?= $m['nama_kategori'] ?>) - Rp<?= number_format($m['harga'], 0, ',', '.') ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label>Jumlah</label>
                <input type="number" name="jumlah" class="form-control" required>
            </div>
            <input type="hidden" name="jenis" id="jenis" value="">
            <div class="col-md-2 d-flex align-items-end">
                <button name="pesan" class="btn btn-success w-100">Pesan</button>
            </div>
        </form>

        <h3 class="text-center mt-5">📋 Riwayat Pesanan</h3>
        <table class="table table-bordered table-striped text-center mt-3">
            <thead>
                <tr>
                    <th>Produk</th>
                    <th>Jenis</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Total</th>
                    <th>Tanggal</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $data->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['produk']) ?></td>
                    <td><?= ucfirst($row['jenis']) ?></td>
                    <td>Rp <?= number_format($row['harga'], 0, ',', '.') ?></td>
                    <td><?= $row['jumlah'] ?></td>
                    <td>Rp <?= number_format($row['total'], 0, ',', '.') ?></td>
                    <td><?= $row['tanggal'] ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
