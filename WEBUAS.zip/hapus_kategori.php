<?php
// hapus_kategori.php
include 'config.php';

// Cek apakah user sudah login dan punya hak admin
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Cek apakah parameter 'id' dikirim
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // amankan input agar hanya angka

    // Cek apakah kategori masih digunakan di tabel merchandise
    $cek = $conn->query("SELECT * FROM merchandise WHERE kategori_id = $id");
    if ($cek->num_rows > 0) {
        // Jika kategori masih digunakan, tolak hapus
        $_SESSION['pesan'] = "Kategori tidak dapat dihapus karena masih digunakan.";
    } else {
        // Hapus kategori
        $conn->query("DELETE FROM kategori WHERE id = $id");
        $_SESSION['pesan'] = "Kategori berhasil dihapus.";
    }
}

// Redirect kembali ke halaman kategori
header("Location: kategori.php");
exit;
?>
